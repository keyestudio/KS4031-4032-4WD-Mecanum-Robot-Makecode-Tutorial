from microbit import *
from keyes_mecanum_Car import *
mecanumCar = Mecanum_Car_Driver()
display.show(Image.HAPPY)
val_LL = 0
val_RR = 0
while True:
    val_LL = pin1.read_digital()
    val_RR = pin2.read_digital()
    if val_LL == 0 and val_RR == 1:
        mecanumCar.Motor_Upper_L(1, 220)
        mecanumCar.Motor_Lower_L(1, 220)
        mecanumCar.Motor_Upper_R(0, 120)
        mecanumCar.Motor_Lower_R(0, 120)
    elif val_LL == 1 and val_RR == 0:
        mecanumCar.Motor_Upper_L(0, 120)
        mecanumCar.Motor_Lower_L(0, 120)
        mecanumCar.Motor_Upper_R(1, 220)
        mecanumCar.Motor_Lower_R(1, 220)
    elif val_LL == 0 and val_RR == 0:
        mecanumCar.Motor_Upper_L(0, 0)
        mecanumCar.Motor_Lower_L(0, 0)
        mecanumCar.Motor_Upper_R(0, 0)
        mecanumCar.Motor_Lower_R(0, 0)
    else:
        mecanumCar.Motor_Upper_L(1, 100)
        mecanumCar.Motor_Lower_L(1, 100)
        mecanumCar.Motor_Upper_R(1, 100)
        mecanumCar.Motor_Lower_R(1, 100)
