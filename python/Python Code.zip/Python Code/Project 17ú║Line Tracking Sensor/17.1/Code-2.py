from microbit import *
val_LL = 0
val_RR = 0
while True:
    val_LL = pin1.read_digital()
    val_RR = pin2.read_digital()
    if val_LL == 0 and val_RR == 1:
        display.show(Image.ARROW_W)
    elif val_LL == 1 and val_RR == 0:
        display.show(Image.ARROW_E)
    elif val_LL == 1 and val_RR == 1:
        display.show(Image.ARROW_N)
    else:
        display.show(Image("00900:""09990:""99999:""99999:""09090"))
