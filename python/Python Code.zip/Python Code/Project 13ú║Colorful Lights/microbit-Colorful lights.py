from microbit import *
from keyes_mecanum_Car import *

mecanumCar = Mecanum_Car_Driver()

while True:
    mecanumCar.left_led(1)
    mecanumCar.right_led(1)
    sleep(3000)
    mecanumCar.left_led(0)
    mecanumCar.right_led(0)
    sleep(3000)
